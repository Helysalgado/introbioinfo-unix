# Guía docente — casos ciegos para S34

## Propósito

Estos casos permiten realizar la evidencia integradora de S34 sin revelar la anotación funcional en el encabezado FASTA.

La secuencia se conserva exactamente. Solo se reemplaza el encabezado.

## Casos

### Caso A — dificultad conceptual

Fuente: `NP_000508.fasta`, hemoglobina subunidad alfa humana.

En el acervo del curso, `NP_000508.1` y `NP_000549.1` tienen exactamente la misma secuencia proteica. Este caso es especialmente valioso porque el estudiante puede inferir con fuerza que se trata de una alfa-globina, pero la secuencia proteica por sí sola no permite decidir cuál de esos dos genes humanos fue el origen.

La conclusión excelente no es “adivinar HBA1/HBA2”, sino declarar ese límite.

### Caso B — dificultad intermedia

Fuente: `NP_001188320.fasta`, hemoglobina beta adulta de ratón.

Permite contrastar alfa y beta globinas y discutir similitud, historia génica y límites de la transferencia de función.

### Caso C — dificultad mayor

Fuente: `NP_001005092.fasta`, hemoglobina zeta de Xenopus tropicalis.

Permite comprobar si el estudiante integra métricas, contexto y relaciones dentro de una familia sin convertir el primer hit en conclusión.

## Uso recomendado

Asigne un caso por equipo. Si desea comparar estrategias, entregue el mismo caso a dos equipos sin avisarles.

No revele `clave-casos.tsv` hasta después de la defensa.

## Verificación de integridad

`clave-casos.tsv` incluye la longitud y MD5 de cada secuencia para demostrar que la anonimización no modificó el contenido biológico.
