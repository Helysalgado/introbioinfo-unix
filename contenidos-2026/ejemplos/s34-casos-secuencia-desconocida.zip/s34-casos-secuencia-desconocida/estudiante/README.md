# Casos de estudio — S34

Este directorio contiene secuencias proteicas cuya identidad funcional fue ocultada deliberadamente.

## Regla

Trabaja únicamente con el contenido de los FASTA y con la evidencia que produzcas durante tu análisis.

No intentes inferir la respuesta a partir del nombre del archivo ni buscar una “clave” externa.

## Archivos

- `caso_A.faa`
- `caso_B.faa`
- `caso_C.faa`

Cada equipo puede recibir uno de los casos.

El encabezado fue sustituido por un seudónimo neutro. La secuencia de aminoácidos **no fue modificada**.

Tu objetivo no es recuperar un identificador exacto a cualquier costo. Tu objetivo es construir la hipótesis biológica mejor sustentada y declarar con precisión qué no puede decidirse con la evidencia disponible.
